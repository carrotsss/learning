package cn.bcw_02_nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

/**
 * Created by carrots on 2019/1/30.
 */
public class TransferToServer2 {

    public static void main(String[] args) throws IOException{
        ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
        ServerSocket ss = serverSocketChannel.socket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress("localhost",9206));
        System.out.println("监听接口：" + new InetSocketAddress("localhost",9026).toString());

        ByteBuffer dst = ByteBuffer.allocate(4096);

        while (true){
            SocketChannel channel = serverSocketChannel.accept();
            System.out.println("acceted :" + channel);
            channel.configureBlocking(true);
            int nread = 0;
            while (nread  != -1){
                try{
                    nread = channel.read(dst);
                    byte[] array = dst.array();
                    String string = new String(array,0 ,dst.position());
                    System.out.println(string);
                    dst.clear();
                }catch (Exception e ){
                    e.printStackTrace();
                    nread = -1;
                }
            }
        }







    }



}
