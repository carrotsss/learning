package cn.bcw_02_nio;

import java.io.FileInputStream;
import java.net.InetSocketAddress;
import java.nio.channels.FileChannel;
import java.nio.channels.SocketChannel;

/**
 * Created by carrots on 2019/1/30.
 */
public class TransferToClient2 {

    public static void main(String[] args) throws Exception{
        long start = System.currentTimeMillis();
        SocketChannel sc = SocketChannel.open();
        sc.connect(new InetSocketAddress("localhsot", 9026));
        sc.configureBlocking(true);
        FileChannel fc = new FileInputStream("c:/sss.txt").getChannel();
        long size = fc.size();
        int pos = 0;
        int offset = 4096;
        long curnset = 0;
        long counts = 0;
        while (pos<size){
            curnset = fc.transferTo(pos,4096,sc);
            pos+=offset;
            counts+=curnset;
        }
        fc.close();
        sc.close();
        System.out.println(counts);
        System.out.println("bytes send ====" + counts + "and totaltime=="+
        +(System.currentTimeMillis()-start));
    }

}
